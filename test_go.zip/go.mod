module test

go 1.26.2

require (
	github.com/golang-jwt/jwt/v5 v5.3.1
	github.com/lib/pq v1.12.3
	golang.org/x/crypto v0.50.0
	golang.org/x/sys v0.43.0
)
